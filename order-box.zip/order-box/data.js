const menu_items = [{
    id: 1,
    title: 'Hamburger',
    price: 80,
    img: './images/hamburger.png'
},
{
    id: 2,
    title: 'Coffee',
    price: 100,
    img: './images/coffee.png'
},
{
    id: 3,
    title: 'Cola',
    price: 60,
    img: './images/cola.svg'
}, {
    id: 4,
    title: 'Tea',
    price: 50,
    img: './images/tea.svg'
},
{
    id: 5,
    title: 'Cheeseburger',
    price: 100,
    img: './images/cheeseburger.svg'
},
{
    id: 6,
    title: 'Fries',
    price: 40,
    img: './images/fries.svg'
}
]

let orders_basket = []